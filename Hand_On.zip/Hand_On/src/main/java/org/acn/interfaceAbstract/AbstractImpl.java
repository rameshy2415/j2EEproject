package org.acn.interfaceAbstract;

public class AbstractImpl extends AbstractDemo{

	@Override
	public void setValue() {
	System.out.println("Hello value");
		
	}

}
