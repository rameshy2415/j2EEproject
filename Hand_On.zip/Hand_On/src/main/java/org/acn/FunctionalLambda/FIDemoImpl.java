package org.acn.FunctionalLambda;

public class FIDemoImpl implements FIDemo {
	public int add(int a, int b) {
		return a+b;
	}

}
