package com.acn.markerInterface;

import java.io.Serializable;

public class SerialziableDemo implements Serializable{
	String name;
	int age;
	public SerialziableDemo(String name, int age) {
		this.name = name;
		this.age = age;
	}
	

}
