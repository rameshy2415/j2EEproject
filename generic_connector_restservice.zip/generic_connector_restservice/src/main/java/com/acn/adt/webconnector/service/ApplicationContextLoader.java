package com.acn.adt.webconnector.service;

import java.io.File;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationContextLoader {

	private static ApplicationContext context;
	private static final String BEANS_XML = "classpath*:**/webservice_application_context.xml";
	private static final String CONFIG_PROPERTY = "path";
	//static boolean isNew=Boolean.FALSE;
	public static boolean loadContextIfFileIsModified() {
		boolean isContextLoadingRequired = isConfigurationFileModified();
		
		if(isContextLoadingRequired){
			context=new ClassPathXmlApplicationContext(BEANS_XML);
			//isNew=Boolean.TRUE;
		}
		return isContextLoadingRequired;
	}	
	

	private static boolean isConfigurationFileModified() {
		boolean isFileModified = false;
		context = ApplicationContextProvider.getApplicationContext();		
		File configFile = new File(System.getProperty(CONFIG_PROPERTY));
		File configDir = configFile.getParentFile();
		if(configDir.isDirectory()){
			File[] fileList = configDir.listFiles();					
			for(File file : fileList){
				if(file.isFile()){
					if(isFileModifiedAfterContextLoading(context, file)){
						isFileModified = true;
					}
				}
			}			
		}
		return isFileModified;	
	}

	private static boolean isFileModifiedAfterContextLoading(ApplicationContext context, File file) {
		boolean isModified = false;
		long fileModificationTimestamp = file.lastModified();
		long contextLoadingTimestamp = context.getStartupDate();
		if(fileModificationTimestamp>contextLoadingTimestamp){
			isModified = true;
		} 
		return isModified;
	}

}
