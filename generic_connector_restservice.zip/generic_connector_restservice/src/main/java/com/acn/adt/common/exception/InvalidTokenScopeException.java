package com.acn.adt.common.exception;

public class InvalidTokenScopeException extends Exception {
	
private static final String MESSAGE = "Invalid Token Scope was provided.";
	
	public InvalidTokenScopeException() {
		this(MESSAGE);
	}

	public InvalidTokenScopeException(String message) {
		super(message);
	}
	
	public InvalidTokenScopeException(Throwable th) {
		this(MESSAGE, th);
	}

	public InvalidTokenScopeException(String message, Throwable th) {
		super(message,th);
	}

}
