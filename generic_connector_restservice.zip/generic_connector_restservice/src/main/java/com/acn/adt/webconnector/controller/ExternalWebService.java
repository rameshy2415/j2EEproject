package com.acn.adt.webconnector.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.acn.adt.bean.WebServiceResponse;
import com.acn.adt.utility.ResourceValidator;
import com.acn.adt.webconnector.service.ApplicationContextLoader;
import com.acn.adt.webconnector.service.ApplicationContextProvider;
import com.acn.adt.webconnector.service.TokenDetails;
import com.xsd.maven.parser.GenericConnectorProcessor;

import ch.qos.logback.classic.LoggerContext;


@RestController
@RequestMapping("/restservice")
public class ExternalWebService {
    private final Logger _logger = LoggerFactory.getLogger(ExternalWebService.class);
        
    private ApplicationContext context;
    private GenericConnectorProcessor genericConnectorProcessor;
    private TokenDetails tokenDetails;
    
    @RequestMapping(value = "/outflow",method = RequestMethod.POST)
    public ResponseEntity<String> getinput(@RequestHeader HttpHeaders httpheaders,@RequestParam(required = false, value = "projId") String projId/*,@RequestBody String jsonObject*/) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	
    	boolean isFileModifed=ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector webservice");   	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeGenericConnectorAsService(projId, isFileModifed);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	
    	return new ResponseEntity<String>(output,statusCode); 
    }
     
     @RequestMapping(value = "/inflow",method = RequestMethod.POST,   /*headers="Content-Type=application/xml;charset=utf-8"*/consumes ="application/xml; charset=UTF-8", produces="application/xml; charset=UTF-8")
     public ResponseEntity<String> getselfinput(@RequestHeader HttpHeaders httpheaders/*,@RequestParam(required = false, value = "inputXML") String inputXML*/,@RequestBody String inputXML) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	
    	ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector webservice");    	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeSelfHealingAsService(inputXML);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    		_logger.debug("Response message: "+output);
    		_logger.debug("Response Status: "+isSuccess);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	HttpHeaders responseHeaders = new HttpHeaders(); responseHeaders.add("Content-Type", "application/xml; charset=UTF-8"); 
    	ResponseEntity<String> responseEntity=new ResponseEntity<String>(new String(output.getBytes("UTF-8"),"UTF-8"),responseHeaders ,statusCode);
    	return responseEntity;
    }
     
     @RequestMapping(value = "/requirement",method = RequestMethod.POST,   /*headers="Content-Type=application/xml;charset=utf-8"*/consumes ="application/xml; charset=UTF-8", produces="application/xml; charset=UTF-8")
     public ResponseEntity<String> getRequirementInput(@RequestHeader HttpHeaders httpheaders/*,@RequestParam(required = false, value = "inputXML") String inputXML*/,@RequestBody String inputXML) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	
    	ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector webservice");    	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeRequirementAsService(inputXML);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    		_logger.debug("Response message: "+output);
    		_logger.debug("Response Status: "+isSuccess);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	
    	HttpHeaders responseHeaders = new HttpHeaders(); responseHeaders.add("Content-Type", "application/xml; charset=UTF-8"); 
    	ResponseEntity<String> responseEntity=new ResponseEntity<String>(new String(output.getBytes("UTF-8"),"UTF-8"),responseHeaders ,statusCode);
    	return responseEntity;
    } 
     
     @RequestMapping(value = "/receivable",method = RequestMethod.POST,   /*headers="Content-Type=application/xml;charset=utf-8"*/consumes ="application/xml; charset=UTF-8", produces="application/xml; charset=UTF-8")
     public ResponseEntity<String> getReceivableInput(@RequestHeader HttpHeaders httpheaders/*,@RequestParam(required = false, value = "inputXML") String inputXML*/,@RequestBody String inputXML) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	
    	ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector webservice");    	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeReceivableAsService(inputXML);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    		_logger.debug("Response message: "+output);
    		_logger.debug("Response Status: "+isSuccess);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	
    	HttpHeaders responseHeaders = new HttpHeaders(); responseHeaders.add("Content-Type", "application/xml; charset=UTF-8"); 
    	ResponseEntity<String> responseEntity=new ResponseEntity<String>(new String(output.getBytes("UTF-8"),"UTF-8"),responseHeaders ,statusCode);
    	return responseEntity;
    }
     
     @RequestMapping(value = "/release",method = RequestMethod.POST,  /*headers="Content-Type=application/xml;charset=utf-8"*/consumes ="application/xml; charset=UTF-8", produces="application/xml; charset=UTF-8")
     public ResponseEntity<String> getRelease(@RequestHeader HttpHeaders httpheaders,@RequestBody String inputXML) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector Release webservice");    	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeReleaseAsService(inputXML);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    		_logger.debug("Response message: "+output);
    		_logger.debug("Response Status: "+isSuccess);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	HttpHeaders responseHeaders = new HttpHeaders(); responseHeaders.add("Content-Type", "application/xml; charset=UTF-8"); 
    	ResponseEntity<String> responseEntity=new ResponseEntity<String>(new String(output.getBytes("UTF-8"),"UTF-8"),responseHeaders ,statusCode);
    	return responseEntity;
    }
     
     @RequestMapping(value = "/deliverable",method = RequestMethod.POST,   /*headers="Content-Type=application/xml;charset=utf-8"*/consumes ="application/xml; charset=UTF-8", produces="application/xml; charset=UTF-8")
     public ResponseEntity<String> getDeliverableInput(@RequestHeader HttpHeaders httpheaders/*,@RequestParam(required = false, value = "inputXML") String inputXML*/,@RequestBody String inputXML) throws Exception{
    	MDC.put("USER_HOME", System.getProperty("Logger_loc")+"\\API_Logs\\GC_Webservice");
    	
    	ApplicationContextLoader.loadContextIfFileIsModified();
    	_logger.info("Starting Generic Connector webservice");    	
    	
    	context = ApplicationContextProvider.getApplicationContext();    	   	
    	genericConnectorProcessor=(GenericConnectorProcessor)context.getBean("genericConnectorProcessor");
    	tokenDetails=(TokenDetails)context.getBean("tokenDetails");
    	
    	tokenDetails.setConnectorXMLPath(genericConnectorProcessor.getMarshaller().getResources().getConnectorXMLPath());
    	WebServiceResponse webServiceResponse;
    	String output="OAuth validation failed";
    	_logger.info("Token validation started");
    	Boolean val=tokenDetails.tokenValidator(httpheaders);
    	boolean isSuccess=Boolean.FALSE;
    	HttpStatus statusCode=HttpStatus.BAD_REQUEST;
    	
    	if(val){
    		_logger.info("Token validation is successfull");
    		output="OAuth validation is successfull";
    		
    		webServiceResponse=genericConnectorProcessor.initializeDeliverableAsService(inputXML);
    		output=webServiceResponse.getResponseMessage();
    		isSuccess=webServiceResponse.isStatus();
    		_logger.info(output);
    		_logger.debug("Response message: "+output);
    		_logger.debug("Response Status: "+isSuccess);
    	}
    	else{
    		_logger.info("Token validation is failed");
    		output="OAuth validation is failed";
    		return new ResponseEntity<String>(output,HttpStatus.UNAUTHORIZED);
    	}
    	if(isSuccess){
    		 statusCode=HttpStatus.OK;
    	}
    	HttpHeaders responseHeaders = new HttpHeaders(); responseHeaders.add("Content-Type", "application/xml; charset=UTF-8"); 
    	ResponseEntity<String> responseEntity=new ResponseEntity<String>(new String(output.getBytes("UTF-8"),"UTF-8"),responseHeaders ,statusCode);
    	return responseEntity;
    }
    
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<String> getStartingPage()
    {
          String output = "<h1>Hello World!<h1>" +
                      "<p>RESTful Service is running ... <br>Ping @ " + new Date().toString() + "</p<br>";
          return new ResponseEntity<String>(output,HttpStatus.OK); 
    }

	public GenericConnectorProcessor getGenericConnectorProcessor() {
		return genericConnectorProcessor;
	}

	public void setGenericConnectorProcessor(GenericConnectorProcessor genericConnectorProcessor) {
		this.genericConnectorProcessor = genericConnectorProcessor;
	}

	public TokenDetails getTokenDetails() {
		return tokenDetails;
	}

	public void setTokenDetails(TokenDetails tokenDetails) {
		this.tokenDetails = tokenDetails;
	}
	
	
	private void loadAllConfigurtionFiles(ApplicationContext context) {
		System.out.println("files has been changed");
	}  
}