package com.acn.adt.common.exception;

public class KeyFetchException extends Exception {
	
	private static final String GENERAL_EXCEPTION_MESSAGE = "Public Key could not be fetched from the certificate";
	
	private Throwable cause;
	private String message;
	
	public KeyFetchException() {
		this(GENERAL_EXCEPTION_MESSAGE);
	}
	
	public KeyFetchException(String msg) {
		this(msg, null);
	}
	
	public KeyFetchException(Throwable cause) {
		this(GENERAL_EXCEPTION_MESSAGE, cause);
	}
	
	public KeyFetchException(String msg, Throwable cause) {
		this.message = msg;
		this.cause = cause;
	}

	@Override
	public Throwable getCause() {
		return this.cause;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

}
