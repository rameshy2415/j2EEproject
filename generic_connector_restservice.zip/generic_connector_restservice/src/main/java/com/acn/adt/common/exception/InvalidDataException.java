package com.acn.adt.common.exception;

@SuppressWarnings("serial")
public class InvalidDataException extends Exception {

	private static final String MESSAGE = "Invalid data provided.";
	
	public InvalidDataException() {
		this(MESSAGE);
	}

	public InvalidDataException(String message) {
		super(message);
	}
	
	public InvalidDataException(Throwable th) {
		this(MESSAGE, th);
	}

	public InvalidDataException(String message, Throwable th) {
		super(message,th);	
	}
	
	
}
