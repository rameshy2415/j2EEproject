package com.acn.adt.webconnector.config;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/*@EnableWebMvc
@Configuration
@ComponentScan({"com.acn.adt","com.xsd.maven","com.xsd.parser"})*/
//@SpringBootApplication(scanBasePackages={"com.acn.adt","com.xsd.maven","com.xsd.parser"}) 
public class WebConfig extends WebMvcConfigurerAdapter {
	
	

}