package com.acn.adt.common.exception;

public class TokenValidationException extends Exception {
	
	private static final String GENERAL_EXCEPTION_MESSAGE = "Public Key could not be fetched from the certificate";
	
	private Throwable cause;
	private String message;
	
	public TokenValidationException() {
		this(GENERAL_EXCEPTION_MESSAGE);
	}
	
	public TokenValidationException(String msg) {
		this(msg, null);
	}
	
	public TokenValidationException(Throwable cause) {
		this(GENERAL_EXCEPTION_MESSAGE, cause);
	}
	
	public TokenValidationException(String msg, Throwable cause) {
		this.message = msg;
		this.cause = cause;
	}

	@Override
	public Throwable getCause() {
		return this.cause;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

}
