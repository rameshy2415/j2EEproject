package com.acn.adt.common.exception;

public class InvalidTokenException extends Exception {
	
private static final String MESSAGE = "Invalid Token was provided.";
	
	public InvalidTokenException() {
		this(MESSAGE);
	}

	public InvalidTokenException(String message) {
		super(message);
	}
	
	public InvalidTokenException(Throwable th) {
		this(MESSAGE, th);
	}

	public InvalidTokenException(String message, Throwable th) {
		super(message,th);
	}

}
