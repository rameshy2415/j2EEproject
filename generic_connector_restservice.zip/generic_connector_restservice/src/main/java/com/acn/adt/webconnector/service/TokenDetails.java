package com.acn.adt.webconnector.service;

import java.io.File;
import java.io.IOException;

import javax.crypto.SecretKey;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.acn.adt.AuthProvider.AuthServiceImpl;
import com.acn.adt.AuthProvider.OAuthDetails;
import com.acn.adt.common.exception.InvalidDataException;
import com.acn.adt.common.exception.TokenValidationException;
import com.acn.adt.exception.DecryptionException;
import com.acn.adt.utility.Decryptor;


public class TokenDetails {
	
	private String connectorXMLPath;
	private static final Logger _logger = LoggerFactory.getLogger(TokenDetails.class);
	 public Boolean tokenValidator(HttpHeaders headers)  {
		 boolean isNew = Boolean.TRUE;
		 try{
		 if(!StringUtils.isEmpty(connectorXMLPath)){
			 _logger.info("Reading Generic Connector xml to get ProtectedBy field and OAuth details" );
			 File fXmlFile = new File(connectorXMLPath);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder;
					dBuilder = dbFactory.newDocumentBuilder();
				
				Document doc = dBuilder.parse(fXmlFile);

				doc.getDocumentElement().normalize();

				//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
				Element ToolGateway = doc.getDocumentElement();
				String protectedby=ToolGateway.getAttribute("protectedBy");
				_logger.info("ProtectedBy field in generic connector xml: "+protectedby);
				if(protectedby==null && protectedby.isEmpty()){
					throw new InvalidDataException("ProtectedBy field can not be empty in Generic Connector xml.");
				}
				NodeList nList = doc.getElementsByTagName("AuthProvider");

				OAuthDetails oad=new OAuthDetails();
				String authid=StringUtils.EMPTY;
				String validationScope=StringUtils.EMPTY;
				String key=StringUtils.EMPTY;
				String tokenCertificate=StringUtils.EMPTY;
				int count=0;
				for (int temp = 0; temp < nList.getLength(); temp++) {

					Node nNode = nList.item(temp);

					if (nNode.getNodeType() == Node.ELEMENT_NODE) {

						Element eElement = (Element) nNode;

						 authid=eElement.getAttribute("AuthProviderUId");
						 validationScope=eElement.getAttribute("Scope");
						 key=eElement.getAttribute("key");
						 tokenCertificate=eElement.getAttribute("CertificatePath");
						 if(StringUtils.equalsIgnoreCase(protectedby, authid)){
							 oad.setScope(validationScope);
							 oad.setKey(key);
							 oad.setTokenCertificate(tokenCertificate);
							 count++;
							 break;
			    			}

					}
				}
				if(count==0){
					throw new TokenValidationException("Auth provider object not present for ProtectedBy : "+protectedby);
				}
				String decryptkey=oad.getKey();
		    	String scope=oad.getScope();	    	
		    	SecretKey originalKey=Decryptor.getOriginalSecretKey(decryptkey);

				String decryptedScope = Decryptor.decryptText(scope, originalKey);
				AuthServiceImpl authserviceimpl=new AuthServiceImpl();
				String tokenstatus=authserviceimpl.validateToken(headers,decryptedScope,oad.getTokenCertificate());
				if(tokenstatus=="Success"){
					isNew= Boolean.TRUE;
				}
				else{
					isNew=Boolean.FALSE;
				} 
		 }else{
			 throw new InvalidDataException("ConnectorXML Path value is null");
		 }
		}
		 catch(InvalidDataException e){
			 _logger.error("OAuth Validation failed: ", e.getMessage());
			 isNew=Boolean.FALSE;
		 } catch (TokenValidationException e) {
			 _logger.error("OAuth Validation failed: ", e.getMessage());
			 isNew=Boolean.FALSE;
		}  catch (ParserConfigurationException e) {
			 _logger.error("OAuth Validation failed due to generic connector xml parsing failure");  
			 isNew=Boolean.FALSE;
		} catch (SAXException e) {
			 _logger.error("OAuth Validation failed due to generic connector xml parsing failure");  
			 isNew=Boolean.FALSE;
		} catch (IOException e) {
			 _logger.error("OAuth Validation failed due to generic connector xml can not be read");
			 isNew=Boolean.FALSE;
		} catch (DecryptionException e) {
			 _logger.error("OAuth Validation failed: ", e.getMessage());
			 isNew=Boolean.FALSE;
		} 
			
		 return isNew;		
}

	public String getConnectorXMLPath() {
		return connectorXMLPath;
	}

	public void setConnectorXMLPath(String connectorXMLPath) {
		this.connectorXMLPath = connectorXMLPath;
	}
	 
}
