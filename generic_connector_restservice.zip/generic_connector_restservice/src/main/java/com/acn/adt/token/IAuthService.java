package com.acn.adt.token;

import org.springframework.http.HttpHeaders;

public interface IAuthService {
	public String generateAccessToken(String clId,String clSecret,String scopeparam,String authServerUrl)throws Exception ;
	public String validateToken(HttpHeaders headers,String scopeParam,String psecretkey) throws Exception;
	

}
