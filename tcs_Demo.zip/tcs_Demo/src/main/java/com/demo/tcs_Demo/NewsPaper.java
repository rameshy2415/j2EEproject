package com.demo.tcs_Demo;

public class NewsPaper implements Comparable<NewsPaper> {
	private String regId;
	private String publisher;
	private Double dailyRate;

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(Double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public NewsPaper() {

	}

	public NewsPaper(String regId, String publisher, Double dailyRate) {
		this.regId = regId;
		this.publisher = publisher;
		this.dailyRate = dailyRate;
	}

	@Override
	public int compareTo(NewsPaper o) {

		return (Integer.parseInt(this.getRegId()) - Integer.parseInt(o.getRegId()));
	}

}
