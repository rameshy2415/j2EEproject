package com.demo.tcs_Demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class NewsPaperDemo {
	public static boolean replaceNewsPaperByRegId(NewsPaper arr[], NewsPaper n6) {
		boolean flag = false;
		List<NewsPaper> list = Arrays.asList(arr);
		List<NewsPaper> list1 = new ArrayList<NewsPaper>();
		for (NewsPaper n : list) {
			if (n.getRegId().equals(n6.getRegId())) {
				flag = true;
				list1.add(n6);
			} else {
				list1.add(n);
			}
		}

		System.out.println(flag);
		Collections.sort(list1);
		list1.forEach(i -> System.out.println(i.getRegId() + "\n" + i.getPublisher() + "\n" + i.getDailyRate()));

		// System.out.println(list.toString());
		return flag;

	}
	
	

}
