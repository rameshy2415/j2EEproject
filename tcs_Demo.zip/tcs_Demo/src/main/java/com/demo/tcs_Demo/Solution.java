package com.demo.tcs_Demo;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Solution {

	public static void main(String[] args) {
		// Scanner scan = new Scanner(scan1).useDelimiter("\\S");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter id name and Cost of NewsPaper for 6 News Paper");
		try {
			String a = br.readLine();
			String name = br.readLine();
			double cost = Double.parseDouble(br.readLine());

			String a1 = br.readLine();
			String name1 = br.readLine();
			double cost1 = Double.parseDouble(br.readLine());

			String a2 = br.readLine();
			String name2 = br.readLine();
			double cost2 = Double.parseDouble(br.readLine());

			String a3 = br.readLine();
			String name3 = br.readLine();
			double cost3 = Double.parseDouble(br.readLine());

			String a4 = br.readLine();
			String name4 = br.readLine();
			double cost4 = Double.parseDouble(br.readLine());

			String a5 = br.readLine();
			String name5 = br.readLine();
			double cost5 = Double.parseDouble(br.readLine());
			
			NewsPaper n1 = new NewsPaper(a, name, cost);
			NewsPaper n2 = new NewsPaper(a1, name1, cost1);
			NewsPaper n3 = new NewsPaper(a2, name2, cost2);
			NewsPaper n4 = new NewsPaper(a3, name3, cost3);
			NewsPaper n5 = new NewsPaper(a4, name4, cost4);
			NewsPaper n6 = new NewsPaper(a5, name5, cost5);

			/*
			 * NewsPaper n1 = new NewsPaper("1","Times news",50.0); NewsPaper n2 = new
			 * NewsPaper("3","economic times",55.0); NewsPaper n3 = new
			 * NewsPaper("2","business news",45.5); NewsPaper n4 = new
			 * NewsPaper("4","time mirror",50.5); NewsPaper n5 = new
			 * NewsPaper("5","news ABP",40.0); NewsPaper n6 = new
			 * NewsPaper("2","Business India",44.5);
			 */

			NewsPaper arr[] = { n1, n2, n3, n4, n5 };
			boolean flag = NewsPaperDemo.replaceNewsPaperByRegId(arr, n6);
		} catch (Exception e) {

		}

	}

}
