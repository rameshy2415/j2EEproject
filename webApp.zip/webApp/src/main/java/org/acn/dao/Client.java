package org.acn.dao;

public class Client {

	public static void main(String[] args) {
	LoginDao dao= new LoginDao();
	//dao.createTable();
	dao.insertData();
	//boolean flag=dao.isUserValid("admin", "admin");
	//System.out.println(flag);
	System.out.println("Created");

	}

}
