package org.acn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.acn.daoService.DaoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class LoginDao {
	public static final Logger logger=LoggerFactory.getLogger(LoginDao.class);
	public boolean isUserValid(String un, String pw) {
		org.slf4j.MDC.put("USER_HOME", "C:/Users/ramesh.yadav/Desktop/EWS/hibernateLogs/Native/newLogs");
		boolean flag = false;
		String query = "select * from user where username=? and password=?";
		//String query= "select * from user where username="+un +"and passwprd="+pw;
		try {
			Connection con = DaoService.getConn();
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, un);
			st.setString(2, pw);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {

		}

		return flag;
	}

	public void createTable() {
		Statement stmt = null;
		Connection con = null;
		String sql = "CREATE TABLE  USER " + " (username VARCHAR(255), " + " password VARCHAR(255), "
				+ " PRIMARY KEY ( username ))";
		try {
			con = DaoService.getConn();
			stmt = con.createStatement();
			stmt.executeUpdate(sql);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}

	public void insertData() {
		Statement stmt = null;
		Connection con = null;
		String sql = "INSERT INTO USER " + "VALUES ('Ramesh', 'ramesh')";
		try {
			con = DaoService.getConn();
			stmt = con.createStatement();
			stmt.executeUpdate(sql);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}

}
