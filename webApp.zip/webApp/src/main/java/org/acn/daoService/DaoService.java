package org.acn.daoService;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.sql.DataSource;

public class DaoService {
	private static final String driver="org.h2.Driver";
	private static final String url="jdbc:h2:C:/Users/ramesh.yadav/Desktop/EWS/DB";
	private static final String username="admin";
	private static final String password="admin";
	public static Connection getConn() {
		Connection con=null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, username, password);		
		}catch(Exception e){
			
		}
		return con;
	}
	

}
