package org.acn.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.acn.dao.LoginDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {

	public static final Logger logger = LoggerFactory.getLogger(Login.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String un = request.getParameter("un");
		String pw = request.getParameter("pw");
		HttpSession session = request.getSession();
		session.setAttribute("username", un);

		if (un.equals("Ramesh") && pw.equals("ramesh")) {

			response.sendRedirect("welcome.jsp");

		} else {
			response.sendRedirect("index.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		org.slf4j.MDC.put("USER_HOME", "C:/Users/ramesh.yadav/Desktop/EWS/hibernateLogs/Services");

		String un = request.getParameter("un");
		String pw = request.getParameter("pw");
		String str = "=============LoginServlet Class===================";

		/*
		 * Cookie ck = new Cookie("un", un); 
		 * Cookie ck1 = new Cookie("pw", pw);
		 * response.addCookie(ck);
		 *  response.addCookie(ck1);
		 * 
		 * Cookie cookie[] = request.getCookies(); String str = null; String pw1 = null;
		 * for (Cookie c : cookie) { if (c.getName().equals("un")) { str = c.getValue();
		 * } else if (c.getName().equals("pw")) { pw1 = c.getValue(); } }
		 */
		/*
		 * if (str.equals("Ramesh") && pw1.equals("ramesh")) { PrintWriter out =
		 * response.getWriter(); out.print("Welcom to the Servlet world " + un +
		 * " !!!!"); }
		 */
		// Validating using DATA base !!!!!!!!!!!!!!!!

		logger.info("******************************Getting Session*****************************");

		HttpSession session = request.getSession();
		session.setAttribute("username", un);
		LoginDao dao = new LoginDao();
		logger.info("*****************************Valadating User*****************************");
		if (dao.isUserValid(un, pw)) {
			logger.info("*****************************User Validated*****************************");
			response.sendRedirect("welcome.jsp");

		} else {
			response.sendRedirect("index.jsp");
		}
	}

}
