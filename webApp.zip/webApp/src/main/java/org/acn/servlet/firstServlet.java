package org.acn.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class firstServlet
 */
public class firstServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	/*RequestDispatcher rd= request.getRequestDispatcher("secondServlet");
	rd.forward(request, response);*/
		String str=request.getParameter("t1");
	//	System.out.println(str);
		
		
		//Using session 
		/*HttpSession session=request.getSession();
		session.setAttribute("t1",str);*/
		
		//Using Cookie
		Cookie cookie= new Cookie("cName", str);
		response.addCookie(cookie);
	response.sendRedirect("secondServlet");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
