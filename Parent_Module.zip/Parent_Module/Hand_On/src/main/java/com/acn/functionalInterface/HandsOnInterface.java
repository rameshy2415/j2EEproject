package com.acn.functionalInterface;


//ByDefault in Interface DataMember are final and Static
//ByDefault method are public and Abstract


public interface HandsOnInterface {
	  String name=" ";

}

interface TestInt {
    int m = 0;
    void testMethod();
}

interface TestInt1 {
    int m = 10;
    void testMethod();
}



