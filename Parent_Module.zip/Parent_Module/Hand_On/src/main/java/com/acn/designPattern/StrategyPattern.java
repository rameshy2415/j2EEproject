package com.acn.designPattern;

public interface StrategyPattern {
	public void pay(int amount);

}
