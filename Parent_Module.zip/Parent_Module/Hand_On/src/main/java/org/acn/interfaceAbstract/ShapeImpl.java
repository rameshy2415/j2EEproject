package org.acn.interfaceAbstract;

public class ShapeImpl implements Shape{

	@Override
	public void draw() {
		
		System.out.println("Triangle drawn");
	}

}
