package org.acn.interfaceAbstract;

public abstract class AbstractDemo {
	public abstract void setValue();
	public void display() {
		System.out.println("Hello Display");
	}

}
