package org.acn.FunctionalLambda;

public interface FIDemo {
	public int  add(int a, int b);

}
