package HibernateDemo.HibernateDemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;


/**
 * Hello world!
 *
 */
public class Client 
{
	public static final Logger logger=LoggerFactory.getLogger(Client.class);
    public static void main( String[] args )
    {
    	  	
    	MDC.put("USER_HOME", "C:/Users/ramesh.yadav/Desktop/EWS/hibernateLogs/Services");
    	String str="=============Client Class===================tryis simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";
    	for(int i=0;i<10000;i++) {
    		logger.info(str);
    		
    	}
    	
    	DAO dao = new DAO();
    	/*dao.insert();
    	dao.retrive();*/
    	boolean flag=dao.log();
    	MDC.put("USER_HOME", "C:/Users/ramesh.yadav/Desktop/EWS/hibernateLogs/Services");
    	if(flag) {
    		
    		for(int i=0;i<10000;i++) {
        		logger.info(str);
        		
        	}
    	}
    }
}
