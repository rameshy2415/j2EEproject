package HibernateDemo.HibernateDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "StudentDetails")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
public class StudentDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column
	private int id;

	@Column
	private String fName;

	@Column
	private String branch;

	@Column
	private String sex;

	// @Transient//This column is not going to persist in Data base table
	@Column
	private String mobNo;

	private StudentAddress sAddress;
	
	//@Column(name="LID")
	//@OneToOne//Column name is not allowed in foreign key in hibernate
	/*
	 * CascadeType.ALL will perform all EntityManager operations (PERSIST, REMOVE,
	 * REFRESH, MERGE, DETACH) to the related entities/ collection e.g when Menu
	 * will be Persisted, SubMenu will also be Persisted.
	 */
	@OneToMany(mappedBy="student",fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	private List<LaptopDetails> laptop=new ArrayList<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public StudentAddress getsAddress() {
		return sAddress;
	}

	public void setsAddress(StudentAddress sAddress) {
		this.sAddress = sAddress;
	}

	public List<LaptopDetails> getLaptop() {
		return laptop;
	}

	public void setLaptop(List<LaptopDetails> laptop) {
		this.laptop = laptop;
	}

	@Override
	public String toString() {
		return "StudentDetails [id=" + id + ", fName=" + fName + ", branch=" + branch + ", sex=" + sex + ", mobNo="
				+ mobNo + ", sAddress=" + sAddress + ", laptop=" + laptop + "]";
	}



}
