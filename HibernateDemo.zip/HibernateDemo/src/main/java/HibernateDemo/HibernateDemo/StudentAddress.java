package HibernateDemo.HibernateDemo;

import javax.persistence.Embeddable;

@Embeddable
public class StudentAddress {
	private String city;
	
	private String firstAddress;
	
	private String state;
	
	private long pin;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFirstAddress() {
		return firstAddress;
	}
	public void setFirstAddress(String firstAddress) {
		this.firstAddress = firstAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPin() {
		return pin;
	}
	public void setPin(long pin) {
		this.pin = pin;
	}

}
