package HibernateDemo.HibernateDemo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.jboss.logging.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DAO {
	public static final Logger logger=LoggerFactory.getLogger(DAO.class);

	
	
	/*
	 * Main difference between save and saveOrUpdate method is that save() generates
	 * a new identifier and INSERT record into database while saveOrUpdate can
	 * either INSERT or UPDATE based upon existence of record. Clearly saveOrUpdate
	 * is more flexible in terms of use but it involves an extra processing to find
	 * out whether record already exists in table or not.
	 */
	
	
	/*
	 * transaction boundaries. persist() method guarantees that it will not execute
	 * an INSERT statement if it is called outside of transaction boundaries. save()
	 * method does not guarantee the same,
	 * save return unique identifier and persist does not
	 */

	

	
	public void insert() {
		Session session = DAOService.getSession();
		Transaction tx = session.beginTransaction();

		/*
		 * LaptopDetails ld1 = new LaptopDetails(); ld1.setId(100); ld1.setName("ASUS");
		 * ld1.setPrice(60000); ld1.setStudent(stud);
		 */

		/*
		 * LaptopDetails ld2= new LaptopDetails(); ld2.setId(101); ld2.setName("DELL");
		 * ld2.setPrice(50000);
		 * 
		 * LaptopDetails ld3= new LaptopDetails(); ld3.setId(102); ld3.setName("Apple");
		 * ld3.setPrice(50000);
		 */

		/*
		 * List<LaptopDetails> lList= new ArrayList<>(); lList.add(ld1); lList.add(ld2);
		 * lList.add(ld3);
		 */

		StudentAddress sAddress = new StudentAddress();
		sAddress.setFirstAddress("Vill Telodih");
		sAddress.setCity("Koderma");
		sAddress.setState("Jharkhand");
		sAddress.setPin(825318);

		StudentDetails stud = new StudentDetails();
		stud.setfName("Puja");
		stud.setBranch("IA");
		stud.setMobNo("8270078469");
		stud.setSex("Female");
		stud.setsAddress(sAddress);
		// stud.setLaptop(lList);
		// stud.getLaptop().add(ld1);

		LaptopDetails ld1 = new LaptopDetails();
		ld1.setId(103);
		ld1.setName("Apple");
		ld1.setPrice(70000);
		//ld1.setStudent(stud);
		
		EmployeeDetails ed = new EmployeeDetails();
		//ed.setId(1);
		ed.setName("Ramesh");
		ed.setDept("CSE");
		ed.setSalary(50000);

		//Integer id = (Integer) session.save(stud);
		//Integer lid = (Integer) session.save(ld1);
		//Integer ePid = (Integer) session.save(ed);
		/*Integer ePid = (Integer) */
		session.saveOrUpdate(ed);
		

		tx.commit();
		session.close();
		//System.out.println("Primary id Student Deatils: " + id);
		//System.out.println("Primary id for Laptop: " + lid);
		//System.out.println("Primary id for Laptop: " + ePid);
	}

	public void retrive() {
		EmployeeDetails ld = null;
		Session session = DAOService.getSession();
		Transaction tx = session.beginTransaction();

		//ld = session.get(StudentDetails.class, 1);
		
		
		//Get Method details
		//it will fire the query at the moment when the method is getting called
		//It will not throw an exception if Data is not present in Table
		//It will give u the actual object
		ld = session.get(EmployeeDetails.class, 1);
		
		
		//Load method details
		//will not fire the query untill and unless u are not using the result
		//It will  throw an ObjectNotFound exception if Data is not present in the Table 
		//It will give u the proxy object
		//ld = session.load(EmployeeDetails.class, 9);		
		System.out.println(ld);
		
		
		
		//Below code for Testing 2nd level cache
		/*Session session1 = DAOService.getSession();
		Transaction tx1 = session1.beginTransaction();
		
		ld = session1.get(EmployeeDetails.class, 1);//it will fire the query the moment when the method is getting called
		ld = session1.load(EmployeeDetails.class, 1);//will not hit the query untill and unless u are not using the result
		System.out.println(ld);

		tx1.commit();
		session1.close();*/

		
		float sal=40000;
		Criteria cr=session.createCriteria(EmployeeDetails.class);
		cr.add(Restrictions.eq("salary", 10000));
		List<EmployeeDetails> eList=cr.list();
		//Add logical expression
		Criterion c1=Restrictions.like("name","zara%");
		Criterion c2=Restrictions.gt("salary",sal);		
		LogicalExpression leOr=Restrictions.or(c1,c2);		
		LogicalExpression leAnd=Restrictions.and(c1,c2);		
		cr.add(leOr);
		cr.add(leAnd);
		
		cr.add(Restrictions.eq("salary",sal));
		
		
		
		//Add Sorting using Order
		cr.addOrder(Order.asc("salary"));
		cr.addOrder(Order.desc("salary"));
		
		//Projection and Aggregations
		//We can load partial object from the database
		//We can find the Result of Aggregate functions
		
		/*Projection p1 = Projections.property("name");
		cr.setProjection(p1);*/
		
		cr.setProjection(Projections.rowCount());
		cr.setProjection(Projections.max("salary"));
		
		
		
		//List<EmployeeDetails> eList1=cr.list();		
		eList.stream().forEach(i->System.out.println(i));
		
		tx.commit();
		session.close();
		

	}
	public boolean log() {
		MDC.put("USER_HOME", "C:/Users/ramesh.yadav/Desktop/EWS/hibernateLogs/Native/newLogs");
		String str="=============DAO Class===================try. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";
    	for(int i=0;i<10000;i++) {
    		logger.info(str);
    		
    	}
    	return true;
	}

}
