package HibernateDemo.HibernateDemo;

import org.hibernate.Session;

public class DAOService {
	public static Session getSession() {
		Session session = null;
		if (session == null) {
			session = SessionFactoryClass.getSessionFactory().getCurrentSession();
			//session = SessionFactoryClass.getSessionFactory().openSession();
		}
		return session;
	}

}
