package org.hibernate.compositeKey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity
public class EmployeeId {
	
	    @Column(name = "company_id")
	    private Long companyId;
	 
	    @Column(name = "employee_number")
	    private Long employeeNumber;

		public Long getCompanyId() {
			return companyId;
		}

		public void setCompanyId(Long companyId) {
			this.companyId = companyId;
		}

		public Long getEmployeeNumber() {
			return employeeNumber;
		}

		public void setEmployeeNumber(Long employeeNumber) {
			this.employeeNumber = employeeNumber;
		}
	    
	    

	
	

}
