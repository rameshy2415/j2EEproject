package org.hibernate.compositeKey;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity
public class Employee {
	/*
	 * The @EmbeddedId is used to instruct Hibernate that the Employee entity uses a
	 * compound key.
	 */
	@EmbeddedId
	private EmployeeId empId;
	
	private String name;

	public EmployeeId getEmpId() {
		return empId;
	}

	public void setEmpId(EmployeeId empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}
