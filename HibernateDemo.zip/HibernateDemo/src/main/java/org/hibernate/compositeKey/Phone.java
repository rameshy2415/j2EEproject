package org.hibernate.compositeKey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table
@Entity
public class Phone {

	@Id
	@Column(name = "number")
	private String number;

	@ManyToOne
	@JoinColumns({ @JoinColumn(name = "company_id", referencedColumnName = "company_id"),
			@JoinColumn(name = "employee_number", referencedColumnName = "employee_number") })
	private Employee employee;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	

}
