package com.acn.spring.controller;


import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Admin {
	
	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public String adminView(Model model,Principal principal) {
		
		String name = principal.getName();
		String message= "Welcome to the Spring Security world!!!!!";
		model.addAttribute("userName",name);
		model.addAttribute("message",message);				
		return "admin";
	}
	
	
/*	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public ModelAndView adminView(Model model,Principal principal) {
		ModelAndView mv = new ModelAndView();
		String name = principal.getName();
		String message= "Welcome to the Spring Security world!!!!!";
		model.addAttribute("userName",name);
		model.addAttribute("message",message);
		
		mv.setViewName("admin");
		return mv;
	}*/

}
