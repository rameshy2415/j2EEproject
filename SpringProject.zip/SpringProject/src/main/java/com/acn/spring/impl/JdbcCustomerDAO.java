package com.acn.spring.impl;

import javax.sql.DataSource;

import com.acn.spring.service.CustomerDAO;

public class JdbcCustomerDAO implements CustomerDAO {
	private DataSource datasource;
	

	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}

	@Override
	public void insert(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer findByCustomerId(int custId) {
		// TODO Auto-generated method stub
		return null;
	}

}
