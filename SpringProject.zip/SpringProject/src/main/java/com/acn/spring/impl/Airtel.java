package com.acn.spring.impl;

import com.acn.spring.service.Sim;

public class Airtel implements Sim{
	
	//Student stu;
	
	
	public Airtel() {
		System.out.println("Airtel constructor called");
		
	}

	@Override
	public void call() {
		//stu.display();
		System.out.println("Calling from Airtel Sim");
		
	}

	@Override
	public void message() {
		System.out.println("Messaging from Airtel Sim");
		
	}

	/*public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
		
	}*/
	

}
