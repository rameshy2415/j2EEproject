package com.acn.spring.service;

import com.acn.spring.impl.Customer;

public interface CustomerDAO {
	public void insert(Customer customer);
	public Customer findByCustomerId(int custId);

}
