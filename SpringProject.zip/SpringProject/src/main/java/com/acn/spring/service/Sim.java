package com.acn.spring.service;


//All data members are static ,final,public byDefault
public interface Sim {
	
	public abstract void call();
	void message();//byDefault it will add public and abstract

}
