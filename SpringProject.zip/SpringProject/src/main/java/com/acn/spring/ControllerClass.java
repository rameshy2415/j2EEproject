package com.acn.spring;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/restService")
public class ControllerClass {
	
	
	@RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<String> getStartingPage()
    {
          String output = "<h1>Hello World!<h1>" +
                      "<p>RESTful Service is running ... <br>Ping @ " + new Date().toString() + "</p<br>";
          return new ResponseEntity<String>(output,HttpStatus.OK); 
    }

}
