package com.acn.spring.impl;

import com.acn.spring.service.Sim;

public class Jio implements Sim{
	
	public Jio() {
		System.out.println("Jio constructor called");
	}

	@Override
	public void call() {
		System.out.println("Calling from Jio Sim");
		
	}

	@Override
	public void message() {
		System.out.println("Messaging from Jio Sim");
		
	}

}
