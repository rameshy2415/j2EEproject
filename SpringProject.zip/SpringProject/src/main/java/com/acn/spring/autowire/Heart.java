package com.acn.spring.autowire;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;

public class Heart {
	private String hName;
	private int no;
	
	
	public String gethName() {
		return hName;
	}

	@Required
    @Value("Cat")
	public void sethName(String hName) {
		this.hName = hName;
	}


	public int getNo() {
		return no;
	}

    @Required
    @Value("1")
	public void setNo(int no) {
		this.no = no;
	}


	public void pumping() {
		System.out.println(hName+" Heart is pumping... and Number of heart is "+no );
	}

}
