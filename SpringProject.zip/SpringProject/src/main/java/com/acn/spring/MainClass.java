package com.acn.spring;


import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandler;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.acn.spring.impl.Airtel;
import com.acn.spring.impl.Student;
import com.acn.spring.service.Sim;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		System.out.println("Context Loaded");
		
		/*System.out.println("*******************Using Airtel Obj*****************");
		Airtel air= new Airtel();
		air.call();
		air.message();
		
		
		System.out.println("*******************Using Jio Obj*****************");
		Jio jio= new Jio();
		jio.call();
		jio.message();
		
		
		System.out.println("*******************Using Sim refrence of Airtel obj*****************");
		Sim sim = new Airtel();
		sim.call();
		sim.message();*/
		
		
		System.out.println("*******************Using Spring Config xml Airtel Obj*****************");
		Sim sim=(Airtel)  context.getBean("sim");
		sim.call();
		sim.message();
		//System.out.println(sim);
		
		try {
			String k;
			String v;
            HttpClient httpClient = HttpClient.newHttpClient(); //Create a HttpClient
            System.out.println(httpClient.version());
            HttpRequest httpRequest = HttpRequest.newBuilder().uri(new URI("https://www.google.com/")).GET().build(); //Create a GET request for the given URI
           
            // Map < String, List < String >> headers = httpRequest.headers().map();
           // headers.forEach((k, v) - > System.out.println(k + "-" + v));
            
            HttpResponse < String > response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
          System.out.println("Content: "+ response.toString()+ "and Response Code: "+response.statusCode()); 
        } catch (Exception e) {
            System.out.println("message " + e);
        }
	
		
		
		System.out.println("*******************Student Details*****************");
		Student stu=(Student)context.getBean("student");
		stu.setName("Ramesh");
		stu.display();
		Student stu1=(Student)context.getBean("student");
		stu1.display();

		
	}
	
	
	
}
