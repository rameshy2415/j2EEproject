package com.acn.spring.impl;

public class Student {
	
	private String name;
	
	private int id;
	
	private Address address;

	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	public void display() {
		System.out.println("Student Name "+name +" and ID is  "+id +"  "+address +" ");
	}

}
