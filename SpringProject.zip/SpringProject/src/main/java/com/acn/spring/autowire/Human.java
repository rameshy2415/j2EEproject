package com.acn.spring.autowire;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Human {
	
	@Autowired
	@Qualifier("humanHeart")
	private Heart heart;
	
	//@Autowired
	//@Qualifier("octopusHeart")
	public void setHeart(Heart heart) {
		this.heart = heart;
	}
	
	
	//@Autowired
	public Human(Heart heart) {
		this.heart = heart;
	}
	
	
	public Human() {
		
	}



	public void isAlive() {
		if(heart!=null) {
			heart.pumping();
			System.out.println("You are Alive!!!");
			
		}else {
			System.out.println("You are Dead SORRY!!!!!");
		}
	}

	
	
	

}
