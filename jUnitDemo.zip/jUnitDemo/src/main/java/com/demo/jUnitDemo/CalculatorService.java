package com.demo.jUnitDemo;

public interface CalculatorService {
	int add(int a, int b);

}
