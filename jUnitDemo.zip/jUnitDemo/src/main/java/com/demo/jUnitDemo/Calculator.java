package com.demo.jUnitDemo;

public class Calculator {
	CalculatorService service;
	public Calculator(CalculatorService service) {
		this.service=service;
	}
	public Calculator() {
		
	}

	public int perform(int a, int b) {
		return (service.add(a, b) * a);
	}

}
