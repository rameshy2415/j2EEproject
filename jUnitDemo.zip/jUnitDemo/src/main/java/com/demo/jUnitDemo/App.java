package com.demo.jUnitDemo;

/**
 * Hello world!
 *
 */
public class App{
	public static void main(String[] args)

	{

		try {
			Calculator cal=new Calculator();
			int res=cal.perform(2, 3);
			System.out.println("Result: "+res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
}
