package com.demo.jUnitDemo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.internal.verification.VerificationModeFactory;

import static org.mockito.Mockito.*;

public class CalculatorTest{
	Calculator cal = null;
	CalculatorService service= mock(CalculatorService.class);
	
	@Before
	public void setup() {
		cal=new Calculator(service);
	}

	@Test
	public void testPerform() {
		service.add(3, 3);
		//service.add(3, 3);
		
		when(service.add(3, 3)).thenReturn(6);
		assertFalse(7==(2+3));
		assertEquals(18, cal.perform(3, 3));
		//verify(service).add(3, 3);
		verify(service,VerificationModeFactory.times(2)).add(3, 3);

	}

}
